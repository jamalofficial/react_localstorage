const ReactStore = require('./Store/ReactStore').default;
export default (new ReactStore());